const jobs = [
  "Netwerken",
  "Routers en Switches",
  "Sensoren",
  "IoT-apparaten",
  "Firewalls & Access Points",
  "Smarthomes"
];

fetch("https://reqres.in/api/users?per_page=6")
  .then(res => res.json())
  .then(data => {
    const container = document.getElementById("klanten");
    data.data.forEach((user, index) => {
      const job = jobs[index % jobs.length];
      const card = document.createElement("div");
      card.classList.add("klant");
      card.innerHTML = `
        <img src="${user.avatar}" alt="Foto van ${user.first_name}">
        <h3>${user.first_name} ${user.last_name}</h3>
        <p><strong>Land:</strong> (geen land, demo)</p>
        <p><strong>Beroep:</strong> ${job}</p>
        <p><strong>Email:</strong> ${user.email}</p>
      `;
      container.appendChild(card);
    });
  })
  .catch(error => console.error("Kan gebruikers niet laden:", error));
