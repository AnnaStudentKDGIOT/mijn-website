fetch("https://mockapi.io/api/parking") // vervang met jouw echte API
  .then(response => response.json())
  .then(data => {
    const aside = document.querySelector("aside");
    aside.innerHTML = `
      <h2>${data.naam}</h2>
      <p><strong>Totale capaciteit:</strong> ${data.totaleCapaciteit}</p>
      <p><strong>Beschikbare capaciteit:</strong> ${data.beschikbareCapaciteit}</p>
    `;
  })
  .catch(error => console.error("Fout bij ophalen parkingdata:", error));
