/* In dit script plaats je de code om de kaart te tonen in de aside van de contactpagina. De coördinaten van de parking in Gent zijn: 51.0424221 en 3.7258331.
De initiële grootte is 15 met een maximale zoom van 19.
Gebruik hiervoor de documentatie op https://leafletjs.com/ 
*/

let mapP = L.map('mapP1').setView([51.0424221,3.7258331],13)


L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);



// plaats icon.png (grootte van 60 x60) als marker op de map
let markerIconP1 = L.icon({
    iconUrl: '/contact/assets/images/icon.png',       // Zorg dat icon.png in de juiste map staat
    iconSize: [60, 60],        // Grootte van het icoon
    iconAnchor: [30, 60],      // Punt van het icoon dat overeenkomt met de locatie
    popupAnchor: [0, -60]      // Positie van de popup ten opzichte van het icoon
  });




L.marker([51.23009, 4.41616], { icon: markerIconP1 })
.addTo(map)
.bindPopup("Aangepaste marker met icon.png");