# config.py

# Adafruit IO configuration
ADAFRUIT_IO_USERNAME = 'annaJoKDG'
ADAFRUIT_IO_KEY = 'aio_nJKs70zVt3oOt40sHRAeshYUx7yl'
FEED_KEY = 'notiontracker'

# Notion API configuration
NOTION_TOKEN = 'secret_oxq1E2xXyigkDo4EiDfXoU2b5SwHaZJWeoAkgGyB8Pq'
DATABASE_ID = '43c749fa5ce1496f80848b7865db27a3'

# Telegram API configuration
TELEGRAM_TOKEN = '7160986080:AAEhyp_uu6e9gKdsFLcQKco734kp2hzsUSo'
CHAT_ID = '5847321993'

# Threshold value for notifications

